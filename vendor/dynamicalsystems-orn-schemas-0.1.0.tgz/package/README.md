# @dynamicalsystems/orn-schemas

JSON Schema (2020-12) definitions, TypeBox schemas, and pre-compiled `TypeCompiler` validators for ORN-1 references, manifests, and registry documents.

## Features

- **TypeBox Schemas:** `ReferenceSchema`, `ManifestSchema`, `RegistryEntrySchema`, `RegistryDocSchema`.
- **Pre-compiled Validators:** `validateReference`, `validateManifest`, `validateRegistryEntry`, `validateRegistryDoc` compiled with `TypeCompiler`.
- **RFC 8785 JCS:** Canonical JSON stringifier `jcsStringify` for deterministic payload hashing.
- **Single Runtime Dependency:** `@sinclair/typebox`.

## Installation

```bash
pnpm add @dynamicalsystems/orn-schemas
```

## License

[Apache-2.0](../../LICENSE)
